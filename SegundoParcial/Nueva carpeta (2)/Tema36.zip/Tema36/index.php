<?php
    require 'html/cabecera.html';
    require 'html/menu.html';
?>

<main>
    <h2>Bienvenido</h2>
</main>

<?php
require 'html/pie.html';
?>

