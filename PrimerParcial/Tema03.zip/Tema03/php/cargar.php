<?php

?>

    <section>
        <main>
            <section>
                <article>
                    <form action="" method="">
                        <label for="idnom">Nombre Cuadro: </label>
                        <input type="text" name="nombre" id="idnom">
                        <label for="idart">Artista: </label>
                        <input type="text" name="artista" id="idart">
                        <label for="idprec">Precio: </label>
                        <input type="number" name="precio" id="idprec" min="0">
                        <input type="submit" value="Cargar!">
                    </form>
                </article>
            </section>
        </main>
    </section>

<?php

?>