<?php

?>

    <section>
        <main>
            <section>
                <article>
                    <?php
                    
                    ?>
                </article>
            </section>
        </main>
    </section>

<?php

?>